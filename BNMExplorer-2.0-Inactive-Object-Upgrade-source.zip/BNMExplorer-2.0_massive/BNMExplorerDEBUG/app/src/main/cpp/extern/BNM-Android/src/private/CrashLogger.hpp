#pragma once

// Lightweight native crash diagnostics for BNM Explorer.
// Breadcrumbs are collected before a crash. The signal handler only uses
// async-signal-safe file/syscall operations and does not allocate or lock.

#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <time.h>
#include <ucontext.h>

namespace BNMCrashLog {

static constexpr size_t kSlotCount = 128;
static constexpr size_t kTextSize = 184;
static constexpr size_t kPathSize = 512;

struct Slot {
    std::atomic<uint64_t> sequence{0};
    std::atomic_flag writing = ATOMIC_FLAG_INIT;
    char text[kTextSize]{};
};

inline Slot g_slots[kSlotCount];
inline std::atomic<uint64_t> g_next{0};
inline char g_filePath[kPathSize]{};
inline std::atomic<bool> g_pathReady{false};
static_assert(std::atomic<bool>::is_always_lock_free, "Crash logger requires lock-free boolean atomics");
static_assert(std::atomic<uint64_t>::is_always_lock_free, "Crash logger requires lock-free 64-bit atomics");
inline volatile sig_atomic_t g_installed = 0;
inline struct sigaction g_previous[5]{};
inline constexpr int kSignals[5] = {SIGSEGV, SIGABRT, SIGBUS, SIGILL, SIGFPE};

inline void CopyText(char* dst, size_t cap, const char* src) {
    if (!cap) return;
    size_t i = 0;
    if (src) {
        for (; i + 1 < cap && src[i]; ++i) dst[i] = src[i];
    }
    dst[i] = '\0';
}

inline void Record(const char* event);

inline void RecordPointer(const char* prefix, uintptr_t value) {
    char message[kTextSize]{};
    size_t at = 0;
    if (prefix) for (; prefix[at] && at + 1 < sizeof(message); ++at) message[at] = prefix[at];
    static const char hex[] = "0123456789abcdef";
    char digits[2 * sizeof(uintptr_t)]; size_t count = 0;
    bool started = false;
    for (int shift = static_cast<int>(sizeof(uintptr_t) * 8) - 4; shift >= 0; shift -= 4) {
        unsigned nibble = static_cast<unsigned>((value >> shift) & 0xF);
        if (nibble || started || shift == 0) { digits[count++] = hex[nibble]; started = true; }
    }
    if (at + count >= sizeof(message)) count = sizeof(message) - at - 1;
    for (size_t i = 0; i < count; ++i) message[at++] = digits[i];
    message[at] = '\0';
    Record(message);
}

inline void RecordNamed(const char* prefix, const char* name) {
    char message[kTextSize]{};
    size_t at = 0;
    if (prefix) for (; prefix[at] && at + 1 < sizeof(message); ++at) message[at] = prefix[at];
    if (name) for (size_t i = 0; name[i] && at + 1 < sizeof(message); ++i) message[at++] = name[i];
    message[at] = '\0';
    Record(message);
}

inline void Record(const char* event) {
    if (!event || !*event) return;
    const uint64_t index = g_next.fetch_add(1, std::memory_order_relaxed);
    Slot& slot = g_slots[index % kSlotCount];
    // Never block: a simultaneous writer may be interrupted by a crash.
    if (slot.writing.test_and_set(std::memory_order_acquire)) return;
    // Mark this slot unavailable until the text is completely written.
    slot.sequence.store(0, std::memory_order_relaxed);
    CopyText(slot.text, kTextSize, event);
    slot.sequence.store(index + 1, std::memory_order_release);
    slot.writing.clear(std::memory_order_release);
}

inline void WriteAll(int fd, const char* data, size_t length) {
    while (length) {
        ssize_t written = write(fd, data, length);
        if (written <= 0) return;
        data += written;
        length -= static_cast<size_t>(written);
    }
}

inline size_t AppendLiteral(char* out, size_t at, size_t cap, const char* s) {
    while (*s && at < cap) out[at++] = *s++;
    return at;
}

inline size_t AppendHex(char* out, size_t at, size_t cap, uintptr_t value) {
    static const char digits[] = "0123456789abcdef";
    at = AppendLiteral(out, at, cap, "0x");
    bool started = false;
    for (int shift = static_cast<int>(sizeof(uintptr_t) * 8) - 4; shift >= 0; shift -= 4) {
        unsigned nibble = static_cast<unsigned>((value >> shift) & 0xF);
        if (nibble || started || shift == 0) {
            if (at < cap) out[at++] = digits[nibble];
            started = true;
        }
    }
    return at;
}

inline void WriteCrashReport(int signalNumber, siginfo_t* info, void* context) {
#if !defined(__aarch64__)
    (void)context;
#endif
    if (!g_pathReady.load(std::memory_order_acquire)) return;
    int fd = open(g_filePath, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (fd < 0) return;

    static const char header[] =
        "=== BNM EXPLORER NATIVE CRASH REPORT ===\n"
        "Architecture: ARM64\n"
        "The following breadcrumbs were recorded BEFORE the crash.\n";
    WriteAll(fd, header, sizeof(header) - 1);

    char line[256];
    size_t at = 0;
    at = AppendLiteral(line, at, sizeof(line), "Signal: ");
    const char* signalName = signalNumber == SIGSEGV ? "SIGSEGV" :
        signalNumber == SIGABRT ? "SIGABRT" : signalNumber == SIGBUS ? "SIGBUS" :
        signalNumber == SIGILL ? "SIGILL" : signalNumber == SIGFPE ? "SIGFPE" : "UNKNOWN";
    at = AppendLiteral(line, at, sizeof(line), signalName);
    at = AppendLiteral(line, at, sizeof(line), " (");
    // Signal number is small; convert without snprintf.
    unsigned n = signalNumber < 0 ? 0u : static_cast<unsigned>(signalNumber);
    char digits[12]; size_t count = 0;
    do { digits[count++] = static_cast<char>('0' + (n % 10)); n /= 10; } while (n && count < sizeof(digits));
    while (count && at < sizeof(line)) line[at++] = digits[--count];
    at = AppendLiteral(line, at, sizeof(line), ")\nsi_code: ");
    int code = info ? info->si_code : 0;
    unsigned codeValue = code < 0 ? static_cast<unsigned>(-code) : static_cast<unsigned>(code);
    char codeDigits[12]; size_t codeCount = 0;
    do { codeDigits[codeCount++] = static_cast<char>('0' + (codeValue % 10)); codeValue /= 10; } while (codeValue && codeCount < sizeof(codeDigits));
    if (code < 0 && at < sizeof(line)) line[at++] = '-';
    while (codeCount && at < sizeof(line)) line[at++] = codeDigits[--codeCount];
    if (signalNumber == SIGSEGV || signalNumber == SIGBUS || signalNumber == SIGILL || signalNumber == SIGFPE) {
        at = AppendLiteral(line, at, sizeof(line), "\nFault address: ");
        at = AppendHex(line, at, sizeof(line), reinterpret_cast<uintptr_t>(info ? info->si_addr : nullptr));
    }
    struct timespec crashTime{};
    if (clock_gettime(CLOCK_REALTIME, &crashTime) == 0) {
        at = AppendLiteral(line, at, sizeof(line), "\nCrash epoch seconds: ");
        unsigned long long seconds = static_cast<unsigned long long>(crashTime.tv_sec);
        char timeDigits[24]; size_t timeCount = 0;
        do { timeDigits[timeCount++] = static_cast<char>('0' + (seconds % 10)); seconds /= 10; } while (seconds && timeCount < sizeof(timeDigits));
        while (timeCount && at < sizeof(line)) line[at++] = timeDigits[--timeCount];
    }
    at = AppendLiteral(line, at, sizeof(line), "\nProcess ID: ");
    at = AppendHex(line, at, sizeof(line), static_cast<uintptr_t>(getpid()));
    at = AppendLiteral(line, at, sizeof(line), "\nThread ID: ");
    at = AppendHex(line, at, sizeof(line), static_cast<uintptr_t>(syscall(SYS_gettid)));

#if defined(__aarch64__)
    if (context) {
        auto* uc = static_cast<ucontext_t*>(context);
        at = AppendLiteral(line, at, sizeof(line), "\nPC: ");
        at = AppendHex(line, at, sizeof(line), static_cast<uintptr_t>(uc->uc_mcontext.pc));
        at = AppendLiteral(line, at, sizeof(line), "\nLR: ");
        at = AppendHex(line, at, sizeof(line), static_cast<uintptr_t>(uc->uc_mcontext.regs[30]));
        at = AppendLiteral(line, at, sizeof(line), "\nSP: ");
        at = AppendHex(line, at, sizeof(line), static_cast<uintptr_t>(uc->uc_mcontext.sp));
    }
#endif
    if (at < sizeof(line)) line[at++] = '\n';
    WriteAll(fd, line, at);

    const uint64_t end = g_next.load(std::memory_order_acquire);
    const uint64_t begin = end > kSlotCount ? end - kSlotCount : 0;
    static const char breadcrumbHeader[] = "\n--- Recent BNM / game-operation breadcrumbs (oldest first) ---\n";
    WriteAll(fd, breadcrumbHeader, sizeof(breadcrumbHeader) - 1);
    for (uint64_t i = begin; i < end; ++i) {
        Slot& slot = g_slots[i % kSlotCount];
        // Claim the slot while copying so a concurrent breadcrumb writer
        // cannot modify its character buffer during the crash report.
        if (slot.writing.test_and_set(std::memory_order_acquire)) continue;
        if (slot.sequence.load(std::memory_order_acquire) == i + 1) {
            size_t textLength = 0;
            while (textLength < kTextSize && slot.text[textLength]) ++textLength;
            WriteAll(fd, slot.text, textLength);
            WriteAll(fd, "\n", 1);
        }
        slot.writing.clear(std::memory_order_release);
    }
    static const char footer[] = "\n=== END REPORT ===\n";
    WriteAll(fd, footer, sizeof(footer) - 1);
    fsync(fd);
    close(fd);
}

inline void CrashSignalHandler(int signalNumber, siginfo_t* info, void* context) {
    WriteCrashReport(signalNumber, info, context);
    int index = 0;
    for (; index < 5; ++index) if (kSignals[index] == signalNumber) break;
    if (index < 5) {
        const struct sigaction previous = g_previous[index];
        if ((previous.sa_flags & SA_SIGINFO) && previous.sa_sigaction &&
            previous.sa_sigaction != CrashSignalHandler) {
            previous.sa_sigaction(signalNumber, info, context);
            return;
        }
        if (previous.sa_handler != SIG_DFL && previous.sa_handler != SIG_IGN && previous.sa_handler) {
            previous.sa_handler(signalNumber);
            return;
        }
    }
    // Preserve normal fatal-signal termination and allow Android to produce
    // its native tombstone after our small report has been flushed.
    syscall(SYS_tgkill, getpid(), syscall(SYS_gettid), signalNumber);
    _exit(128 + signalNumber);
}

inline bool InitializePathFromJNI(JNIEnv* env) {
    if (!env) {
        __android_log_print(ANDROID_LOG_WARN, "BNMCrashLogger", "JNI environment unavailable; will retry later");
        return false;
    }

    jclass activityThread = env->FindClass("android/app/ActivityThread");
    if (!activityThread) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        __android_log_print(ANDROID_LOG_WARN, "BNMCrashLogger", "ActivityThread lookup failed; will retry later");
        return false;
    }
    jmethodID currentApplication = env->GetStaticMethodID(
        activityThread, "currentApplication", "()Landroid/app/Application;");
    if (!currentApplication) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(activityThread);
        __android_log_print(ANDROID_LOG_WARN, "BNMCrashLogger", "currentApplication method unavailable; will retry later");
        return false;
    }
    jobject app = env->CallStaticObjectMethod(activityThread, currentApplication);
    if (env->ExceptionCheck()) { env->ExceptionClear(); app = nullptr; }
    env->DeleteLocalRef(activityThread);
    if (!app) {
        __android_log_print(ANDROID_LOG_INFO, "BNMCrashLogger", "Application context not ready; will retry after BNM load callback");
        return false;
    }

    jclass appClass = env->GetObjectClass(app);
    if (!appClass) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteLocalRef(app);
        __android_log_print(ANDROID_LOG_ERROR, "BNMCrashLogger", "Could not inspect Application context");
        return false;
    }

    char packageBuffer[192]{};
    jmethodID getPackageName = env->GetMethodID(appClass, "getPackageName", "()Ljava/lang/String;");
    if (getPackageName) {
        auto packageName = static_cast<jstring>(env->CallObjectMethod(app, getPackageName));
        if (env->ExceptionCheck()) { env->ExceptionClear(); packageName = nullptr; }
        if (packageName) {
            const char* packageChars = env->GetStringUTFChars(packageName, nullptr);
            if (packageChars) {
                CopyText(packageBuffer, sizeof(packageBuffer), packageChars);
                RecordNamed("Game package: ", packageChars);
                env->ReleaseStringUTFChars(packageName, packageChars);
            }
            env->DeleteLocalRef(packageName);
        }
    } else if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    // Android 9+ exposes the actual process name. It can differ from the
    // package name when a game uses a secondary process, so record both.
    jmethodID getProcessName = env->GetStaticMethodID(
        appClass, "getProcessName", "()Ljava/lang/String;");
    if (getProcessName) {
        auto processName = static_cast<jstring>(env->CallStaticObjectMethod(appClass, getProcessName));
        if (env->ExceptionCheck()) { env->ExceptionClear(); processName = nullptr; }
        if (processName) {
            const char* processChars = env->GetStringUTFChars(processName, nullptr);
            if (processChars) {
                RecordNamed("Game process: ", processChars);
                env->ReleaseStringUTFChars(processName, processChars);
            }
            env->DeleteLocalRef(processName);
        }
    } else if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    // Try both app-specific locations independently. A non-null external
    // directory is not proof that it is writable, so failure there must not
    // prevent the private files directory from being tried.
    char candidates[2][kPathSize]{};
    size_t candidateCount = 0;
    jmethodID getExternalFilesDir = env->GetMethodID(
        appClass, "getExternalFilesDir", "(Ljava/lang/String;)Ljava/io/File;");
    if (!getExternalFilesDir) {
        if (env->ExceptionCheck()) env->ExceptionClear();
    } else {
        jobject externalDir = env->CallObjectMethod(app, getExternalFilesDir, nullptr);
        if (env->ExceptionCheck()) { env->ExceptionClear(); externalDir = nullptr; }
        if (externalDir) {
            jclass fileClass = env->GetObjectClass(externalDir);
            jmethodID getAbsolutePath = fileClass ? env->GetMethodID(
                fileClass, "getAbsolutePath", "()Ljava/lang/String;") : nullptr;
            if (!getAbsolutePath && env->ExceptionCheck()) env->ExceptionClear();
            auto path = getAbsolutePath ? static_cast<jstring>(
                env->CallObjectMethod(externalDir, getAbsolutePath)) : nullptr;
            if (env->ExceptionCheck()) { env->ExceptionClear(); path = nullptr; }
            if (path) {
                const char* chars = env->GetStringUTFChars(path, nullptr);
                if (chars) {
                    CopyText(candidates[candidateCount], kPathSize, chars);
                    ++candidateCount;
                    env->ReleaseStringUTFChars(path, chars);
                }
                env->DeleteLocalRef(path);
            }
            if (fileClass) env->DeleteLocalRef(fileClass);
            env->DeleteLocalRef(externalDir);
        }
    }

    jmethodID getFilesDir = env->GetMethodID(appClass, "getFilesDir", "()Ljava/io/File;");
    if (!getFilesDir && env->ExceptionCheck()) env->ExceptionClear();
    if (getFilesDir) {
        jobject privateDir = env->CallObjectMethod(app, getFilesDir);
        if (env->ExceptionCheck()) { env->ExceptionClear(); privateDir = nullptr; }
        if (privateDir) {
            jclass fileClass = env->GetObjectClass(privateDir);
            jmethodID getAbsolutePath = fileClass ? env->GetMethodID(
                fileClass, "getAbsolutePath", "()Ljava/lang/String;") : nullptr;
            if (!getAbsolutePath && env->ExceptionCheck()) env->ExceptionClear();
            auto path = getAbsolutePath ? static_cast<jstring>(
                env->CallObjectMethod(privateDir, getAbsolutePath)) : nullptr;
            if (env->ExceptionCheck()) { env->ExceptionClear(); path = nullptr; }
            if (path) {
                const char* chars = env->GetStringUTFChars(path, nullptr);
                if (chars) {
                    char privateCandidate[kPathSize]{};
                    CopyText(privateCandidate, sizeof(privateCandidate), chars);
                    bool duplicate = candidateCount > 0 &&
                        strncmp(candidates[0], privateCandidate, kPathSize) == 0;
                    if (!duplicate && candidateCount < 2) {
                        CopyText(candidates[candidateCount], kPathSize, privateCandidate);
                        ++candidateCount;
                    }
                    env->ReleaseStringUTFChars(path, chars);
                }
                env->DeleteLocalRef(path);
            }
            if (fileClass) env->DeleteLocalRef(fileClass);
            env->DeleteLocalRef(privateDir);
        }
    }
    env->DeleteLocalRef(appClass);
    env->DeleteLocalRef(app);

    static const char filename[] = "/BNM_CRASH_LOG.txt";
    static const char startupMarker[] =
        "\n=== BNM CRASH LOGGER STARTED ===\n"
        "Logger initialized; crash breadcrumbs are being collected.\n";

    for (size_t i = 0; i < candidateCount; ++i) {
        const size_t length = strnlen(candidates[i], kPathSize);
        if (!length || length >= kPathSize || length + sizeof(filename) > kPathSize) continue;
        char fullPath[kPathSize]{};
        memcpy(fullPath, candidates[i], length);
        memcpy(fullPath + length, filename, sizeof(filename));

        int fd = open(fullPath, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
        if (fd < 0) {
            const int openError = errno;
            __android_log_print(ANDROID_LOG_WARN, "BNMCrashLogger",
                "Cannot open report for package %s at %s (errno=%d); trying next app-specific directory",
                packageBuffer[0] ? packageBuffer : "unknown", fullPath, openError);
            continue;
        }
        WriteAll(fd, startupMarker, sizeof(startupMarker) - 1);
        bool writeOk = (fsync(fd) == 0);
        const int syncError = errno;
        close(fd);
        if (!writeOk) {
            __android_log_print(ANDROID_LOG_WARN, "BNMCrashLogger",
                "Could not flush report for package %s at %s (errno=%d); trying next directory",
                packageBuffer[0] ? packageBuffer : "unknown", fullPath, syncError);
            continue;
        }

        CopyText(g_filePath, sizeof(g_filePath), fullPath);
        g_pathReady.store(true, std::memory_order_release);
        RecordNamed("Crash report destination: ", g_filePath);
        Record("Crash logger startup marker successfully written to disk");
        __android_log_print(ANDROID_LOG_INFO, "BNMCrashLogger",
            "Ready for game package %s; report path: %s",
            packageBuffer[0] ? packageBuffer : "unknown", g_filePath);
        return true;
    }

    __android_log_print(ANDROID_LOG_ERROR, "BNMCrashLogger",
        "No writable app-specific report directory found for game package %s (checked %zu candidates)",
        packageBuffer[0] ? packageBuffer : "unknown", candidateCount);
    return false;
}

inline void InstallHandlers() {
    if (g_installed) return;
    struct sigaction action{};
    sigfillset(&action.sa_mask);
    action.sa_sigaction = CrashSignalHandler;
    action.sa_flags = SA_SIGINFO | SA_RESETHAND;
    for (int i = 0; i < 5; ++i) sigaction(kSignals[i], &action, &g_previous[i]);
    g_installed = 1;
    Record("Crash logger installed; pre-crash breadcrumb buffer active");
}

} // namespace BNMCrashLog
